# PART 1  - Below requirement will take more time than given time frame
Role & password
admin-admin (Only role can login view selectd forms)
user-user
# Requirements:
1.	Form Builder Interface
	--Create a drag-and-drop interface for building forms with different field types: 
    	Text input (single-line and multi-line)
	    Dropdown select (with configurable options)
	    Checkbox groups
	    Date picker
	    Radio button groups
	--Each field should have configurable properties: 
	    Field label
	    Required/optional setting
	    Help text
    	Validation rules (min/max length, pattern, etc.)
