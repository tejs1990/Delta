import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormConfigService } from '../../services/form-config.service';
import { AuthService } from '../../services/auth.service';
@Component({
  selector: 'app-form-list',
  templateUrl: './form-list.component.html',
})
export class FormListComponent implements OnInit {
  forms: any[] = [];
  role: string = '';
  constructor(private formConfig: FormConfigService, private router: Router,private auth: AuthService) {}

  ngOnInit(): void {
    this.forms = this.formConfig.getAllForms();
    this.role = this.auth.getRole()?.toString() || '';
  }

  goToForm(formId: string): void {
    if (this.role !== 'admin' || this.role !== 'admin') {alert("Only admin has access to view");}else{
    this.router.navigate(['/form', formId]);}
  }
}
