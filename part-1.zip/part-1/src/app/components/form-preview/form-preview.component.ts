import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup } from '@angular/forms';
import { FormConfigService } from '../../services/form-config.service';

@Component({
  selector: 'app-form-preview',
  templateUrl: './form-preview.component.html',
  styleUrls: ['./form-preview.component.css']
})
export class FormPreviewComponent implements OnInit {
  formGroup!: FormGroup;
  formConfig: any;
  formId: string = '';
  

  constructor(
    private route: ActivatedRoute,
    private formConfigService: FormConfigService,
    private fb: FormBuilder,
    
  ) {}

  ngOnInit(): void {
    this.formId = this.route.snapshot.paramMap.get('id')!;
    this.formConfig = this.formConfigService.getFormById(this.formId);
    

    if (this.formConfig) {
      const controls: any = {};
      this.formConfig.config.forEach((field: any) => {
        controls[field.name] = ['', field.validators];
      });
      this.formGroup = this.fb.group(controls);
    }
  }

  onSubmit(): void {

    if (this.formGroup.valid) {
      console.log('Submitted:', this.formGroup.value);
      alert(`Form submitted:\n${JSON.stringify(this.formGroup.value, null, 2)}`);
    }
  }
}
