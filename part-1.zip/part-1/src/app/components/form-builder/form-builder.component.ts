import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { CdkDragDrop } from '@angular/cdk/drag-drop';
import { FormConfigService } from '../../services/form-config.service';

@Component({
  selector: 'app-form-builder',
  templateUrl: './form-builder.component.html',
  styleUrls: ['./form-builder.component.css']
})
export class FormBuilderComponent {
  availableFields = [
    { type: 'text', label: 'Text Field' },
    { type: 'email', label: 'Email Field' },
    { type: 'password', label: 'Password Field' },
    { type: 'textarea', label: 'Text Area' },
    { type: 'radio', label: 'Radio Group', options: ['Option 1', 'Option 2'] },
    { type: 'checkbox', label: 'Checkbox' }
  ];

  droppedFields: any[] = [];
  selectedFieldIndex: number | null = null;
  form: FormGroup = this.fb.group({});
  formTitle: string = '';

  constructor(private fb: FormBuilder, private formService: FormConfigService) {}

  drop(event: CdkDragDrop<any[]>) {
    if (event.previousContainer !== event.container) {
      const baseField = event.previousContainer.data[event.previousIndex];
      const field = {
        ...baseField,
        name: `field${this.droppedFields.length + 1}`,
        label: baseField.label,
        required: false,
        minLength: null,
        email: false,
        options: baseField.options || [],
        checked: false
      };

      this.droppedFields.push(field);
      const control = new FormControl(field.type === 'checkbox' ? field.checked : '', []);
      this.form.addControl(field.name, control);
    }
  }

  selectField(index: number) {
    this.selectedFieldIndex = index;
  }

  applyValidation(index: number) {
    const field = this.droppedFields[index];
    const validators = [];

    if (field.required) validators.push(Validators.required);
    if (field.minLength && ['text', 'textarea', 'email', 'password'].includes(field.type)) {
      validators.push(Validators.minLength(field.minLength));
    }
    if (field.email && field.type === 'email') {
      validators.push(Validators.email);
    }

    const control = this.form.get(field.name);
    control?.setValidators(validators);
    control?.updateValueAndValidity();
  }

  getControl(field: any) {
    return this.form.get(field.name);
  }

  toKebabCase(str: string): string {
    return str && str.trim()
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)+/g, '');
  }

  submit() {
    if (!this.formTitle.trim()) {
      alert('Please enter a form title.');
      return;
    }

    if (this.form.invalid) {
      alert('Form is invalid');
      this.form.markAllAsTouched();
      return;
    }

    const config = this.droppedFields.map(field => {
      const validators: any[] = [];

      if (field.required) validators.push(Validators.required);
      if (field.minLength) validators.push(Validators.minLength(field.minLength));
      if (field.email) validators.push(Validators.email);

      return {
        label: field.label,
        name: field.name,
        type: field.type,
        options: field.type === 'radio' ? field.options : undefined,
        validators
      };
    });

    const formTemplate = {
      id: this.toKebabCase(this.formTitle),
      title: this.formTitle.trim(),
      config
    };

    this.formService.addForm(formTemplate);
    alert(`Form "${formTemplate.title}" saved as "${formTemplate.id}"`);
    console.log('Saved Form Template:', formTemplate);

    // Reset builder state
    this.form.reset();
    this.droppedFields = [];
    this.formTitle = '';
    this.selectedFieldIndex = null;
  }
}