import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private isLoggedIn = false;
  private userRole: 'admin' | 'user' | null = null;

  constructor(private router: Router) {}

  login(username: string, password: string): boolean {
    
    if (username === 'admin' && password === 'admin') {
      this.userRole = 'admin';
    } else if (username === 'user' && password === 'user') {
      this.userRole = 'user';
    } else {
      return false;
    }
    this.isLoggedIn = true;
    return true;
  }

  logout() {
    this.isLoggedIn = false;
    this.userRole = null;
    this.router.navigate(['/login']);
  }

  isAuthenticated() {
    return this.isLoggedIn;
  }

  getRole() {
    return this.userRole;
  }
}
