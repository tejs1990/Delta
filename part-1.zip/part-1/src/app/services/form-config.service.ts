import { Injectable } from '@angular/core';
import { Validators } from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class FormConfigService {
  private forms = [
    {
      id: 'contact',
      title: 'Contact',
      config: [
        { label: 'Name', name: 'name', type: 'text', validators: [Validators.required] },
        { label: 'Email', name: 'email', type: 'email', validators: [Validators.required, Validators.email] },
        { label: 'Email', name: 'mobile', type: 'number', validators: [Validators.required] }
      ]
    },
    {
      id: 'feedback',
      title: 'Feedback',
      config: [
        { label: 'Username', name: 'username', type: 'text', validators: [] },
        { label: 'Feedback', name: 'feedback', type: 'textarea', validators: [Validators.required] },
      ]
    },
    {
      id: 'login',
      title: 'Login',
      config: [
        { label: 'Username', name: 'username', type: 'text', validators: [Validators.required] },
        { label: 'Password', name: 'password', type: 'password', validators: [Validators.required] },
      ]
    }
  ];

  getAllForms() {
    return this.forms;
  }

  getFormById(id: string) {
    return this.forms.find(f => f.id === id);
  }

  addForm(form: any) {
    this.forms.push(form);
  }
}
